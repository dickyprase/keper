<ul class="breadcrumb">
  <li><a href="./">Home</a></li>
  <li class="active">404 error</li>
</ul>
<div class='alert alert-danger'>
  
  <strong>404!</strong> Maaf Halaman tidak ditemukan.
</div>