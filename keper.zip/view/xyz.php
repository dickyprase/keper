<ul class="breadcrumb">
  <li class="active">Home</li>
</ul>
<div class="alert alert-info">
  <strong>Selamat Datang! </strong> <u><?php echo ucfirst($_SESSION['username'])  ;?> </u>di aplikasi Keper PostNet.
</div>