<?php
$_SESSION = [];
session_unset();
session_destroy();

echo "<script>window.location.href = 'login.php';</script>";

exit;