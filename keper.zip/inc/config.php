<?php

$servername = "localhost"; 
$username = "root";
$password = "";
$database = "keper2";

// Membuat koneksi
$koneksi = mysqli_connect($servername, $username, $password, $database);


?> 