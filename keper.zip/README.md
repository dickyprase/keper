# Keper PostNet
Aplikasi Tagihan Internet

Aplikasi dibuat menggunakan :
- PHP
- MySQL
- Bootstrap
- DatePicker

Halaman Admin<br/>
Username : admin | Password : admin

Halaman Pelanggan<br/>
Username : user | Password : user
